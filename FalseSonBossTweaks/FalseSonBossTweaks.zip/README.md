# False Son Boss Tweaks

A mod that tweaks the False Son fight, and has various changes. Changes include:

- Tweaks to Eclipse difficulty False Son fight, to make it more fair (less laser/skill steal cooldown)
- Adds a very small delay between the False Son dash and slam, to give you a bit more time to dodge it
- Slowing down the False Son during phase 2 laser. 
- Smaller credit amount for the Prime Meridian stage (450 -> 320)

Credit to PlNK for the mod icon, the goat