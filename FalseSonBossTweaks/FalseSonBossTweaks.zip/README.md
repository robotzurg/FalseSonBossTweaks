# False Son Boss Tweaks

A mod that tweaks the False Son fight, and has various changes. Changes include:

- Tweaks to Eclipse difficulty False Son fight, to make it more fair (longer laser/skill steal attack cooldown)
- Adds a very small delay between the False Son dash and slam, to give you a bit more time to dodge it
- Slowing down the False Son during phase 2 laser. 
- Reducing the number of Golems during phase 2 to a maximum of 3 golems, and making them unable to become elite.
- Smaller credit amount for the Prime Meridian stage (450 -> 320)

## Todo
- Make each change configurable

## Credits
Credit to PlNK for the mod icon, the goat